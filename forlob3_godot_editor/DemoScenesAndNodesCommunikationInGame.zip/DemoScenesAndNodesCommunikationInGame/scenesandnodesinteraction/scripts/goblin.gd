extends enemy
class_name goblin

var movespeed = 100;
var texture: Variant; 

func _init(newMovespeed: int) -> void:
	movespeed = newMovespeed;
	texture = load("res://assets/goblin.jpg");
	weaponPath = "res://scenes/axe.tscn";
	
func getMovespeed() -> int:
	return movespeed;
	
func setMovespeed(newMovespeed: int):
	movespeed = newMovespeed;

func getTexture() -> Texture2D:
	return texture;
	
func getPathToWeapon() -> String:
	return weaponPath;
