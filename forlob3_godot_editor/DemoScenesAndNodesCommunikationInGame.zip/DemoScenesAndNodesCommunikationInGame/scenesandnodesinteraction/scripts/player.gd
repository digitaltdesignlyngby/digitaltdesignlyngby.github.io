extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0
var health = 100;
#@export var weaponDamageListener: PackedScene
@onready var weaponDamageListener = load("res://scenes/axe.tscn").instantiate().get_node("Area2D");

func _ready() -> void:
	
	### VIRKER DESVÆRRE IKKE, og er ikke nødvendigt
	weaponDamageListener.damageTaken.connect(reduceHealth);

func _physics_process(delta: float) -> void:
	# weaponDamageListener.damageTaken.connect(reduceHealth);
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	#weaponDamageListener.damageTaken.connect(reduceHealth);
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	direction = Input.get_axis("ui_up", "ui_down");
	if direction:
		velocity.y = direction * SPEED
	else:
		velocity.y = move_toward(velocity.x, 0, SPEED)

	move_and_slide()

func reduceHealth() -> void:
	print("reducing health...");
	health = health - 2;
	print("Player health: " + health);
