extends enemy
class_name slime

var movespeed = 10;
var texture: Variant; 

func _init(newMovespeed: int) -> void:
	movespeed = newMovespeed;
	texture = load("res://assets/slime.jpg");

func getMovespeed():
	return movespeed;
	
func setMovespeed(newMovespeed: int):
	movespeed = newMovespeed;

func getTexture() -> Texture2D:
	return texture;
	
