extends CharacterBody2D

signal value_changed;

const SPEED = 300.0;
const JUMP_VELOCITY = -400.0;
var remainingRoadDistance = 500.0;

@export_enum("goblin", "slime") var type: int:
	set(value):
		print("hejsa")
		type = value
		emit_signal("value_changed");
# @export var type: enemyTypes;
var selected_entity = null;
var weapon_attached: PackedScene = null;

func _on_value_changed() -> void:
	if (type == 0):
		selected_entity = goblin.new(100);
		$Sprite2D.texture = selected_entity.getTexture();
		selected_entity.setHealth(50);
		### OBS!!!: koden herunder virker kun pga. linje 10 i goblin.gd
		# vedhæft våben 'økse' til fjende
		weapon_attached = load(selected_entity.getPathToWeapon());
		var weapon_scene = weapon_attached.instantiate();
		add_child(weapon_scene);
		# sæt våbnet i en mere ønskelig position ift. fjendens placering
		weapon_scene.global_position = Vector2(position.x - selected_entity.getTexture().get_width() / 2, position.y);
		print(weapon_scene.position);
			
	elif (type == 1):
		selected_entity = slime.new(10);
		$Sprite2D.texture = selected_entity.getTexture();
		selected_entity.setHealth(25);
		#selected_entity.setWeapon(null);

# movement physics for any exisiting types of enemies	
func _physics_process(delta: float) -> void:
	
	move_and_slide()


func moveType1(delta: float) -> void:
	pass
		
func moveType2(delta: float) -> void:
	pass
