extends Node2D
class_name enemy

var health = 100;
var weaponPath: String;

func _init(newHealth: int) -> void:
	health = newHealth;
	
func getHealth():
	return health;
	
func setHealth(newHealth: int):
	health = newHealth;

func getWeaponPath() -> String:
	return weaponPath;
