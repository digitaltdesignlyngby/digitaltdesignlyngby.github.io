extends Area2D

signal damageTaken;
var directionAxe = -1;
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func _physics_process(delta: float) -> void:
	if (rotation < PI/2 and directionAxe > 0):
		rotation = rotation + 0.05 * directionAxe;
	elif (rotation > -PI/2 and directionAxe < 0):
		rotation = rotation + 0.05 * directionAxe;
	else:
		directionAxe = -1 * directionAxe;
	
	
func _on_body_entered(body: Node2D) -> void:
	print(body);
	if (body.is_in_group("Player")):
		print("body entered");
		body.health = body.health - 2;
		print(body.health);
		#damageTaken.emit();
