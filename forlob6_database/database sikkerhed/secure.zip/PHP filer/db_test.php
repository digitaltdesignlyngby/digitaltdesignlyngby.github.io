    <?php
		include 'db_connection_secure.php';
		
		if(isset($_SERVER['HTTP_ORIGIN'])){
			header("Access-Control-Allow-Origin: *");
			header("Access-Control-Max-Age: 60");
		}
		
		if($_SERVER['REQUEST_METHOD'] === "OPTIONS"){
			header("Access-Control-Allow-Methods: POST, OPTIONS");
			header("Access-Control-Allow-Headers: Authorization, Content-Type, Accept, Origin, cache-control");
			http_response_code(200);
			die;
		}
		
		if ($_SERVER['REQUEST_METHOD'] !== "POST"){
			http_response_code(405);
			die;
		}
		
		#Returns information and data to Godot
		function print_response($datasize, $status, $dictionary = [], $error = "none"){
			
			
			$string = "{\"error\" : \"$error\",
						\"command\" : \"$_REQUEST[command]\",
						\"status\" : \"$status\",
						\"datasize\" : $datasize, 
						\"response\" :" . json_encode($dictionary) . "}";	

			#Print out json to Godot
			echo $string;
		}

		function verify_nonce($pdo, $secret = "1234567890"){
			
			//Check if cnonce has been sent in header
			if(!isset($_SERVER['HTTP_CNONCE'])){
				print_response(0, "no_return", [], "invalide_nonce");
				return false;
			}
			
			//Get users nonce from database found by IP adress
			$template = "SELECT nonce FROM `nonces` WHERE ip_address = :ip";
			$sth = $pdo -> prepare($template);
			$sth -> execute(["ip" => $_SERVER['REMOTE_ADDR']]);
			$data = $sth -> fetchAll(PDO::FETCH_ASSOC);
			
			//Check if data is not empty
			if(!isset($data) or sizeof($data) <= 0){
				print_response(0, "no_return", [], "server_missing_nonce");
				return false;
			}
			
			//Get server nonce from user
			$server_nonce = $data[0]['nonce'];
			
			//Compair hash from user with servers hash
			if (hash('sha256', $server_nonce . $_SERVER['HTTP_CNONCE'] . file_get_contents("php://input") . $secret) != $_SERVER["HTTP_HASH"]){
					print_response(0, "no_return", [], "invalid_nonce_or_hash");
					return false;
			}
			
			//If all is good, return true
			return true;			
		}
		
		#Handle error: 
		#Missing command
		if (!isset($_REQUEST['command']) or $_REQUEST['command'] === null){
			print_response(0, "no_return", [], "missing_command");
			#echo "{\"error\":\"missing_command\",\"response\":{}}";
			die;
		}
		
		#Missing data
		if (!isset($_REQUEST['data']) or $_REQUEST['data'] === null){
			print_response(0, "no_return",[], "missing_data");
			die;
		}
			
		
		#Convert Godot json to dictionary
		$dict_from_json = json_decode($_REQUEST['data'], true);

		
		#Is dictionary valid
		if ($dict_from_json === null){
			print_response(0, "no_return", [], "invalid_json");
			die;
		}
		
		switch ($_REQUEST['command']){
			
			case "get_nonce":
			
				$bytes = random_bytes(32);
				//Create new server nonce 
				$nonce = hash('sha256', $bytes);
				
				//Insert new server nonce into database together with users IP address
				$template = "INSERT INTO `nonces` (ip_address, nonce) VALUES (:ip, :nonce) ON DUPLICATE KEY
				UPDATE nonce = :nonce_update";
				
				$pdo = OpenConnPDO();
				
				$sth = $pdo -> prepare($template);
				$sth -> execute(["ip" => $_SERVER['REMOTE_ADDR'], "nonce" => $nonce, "nonce_update" => $nonce]);
				
				CloseConnPDO($pdo);
				
				//Return new nonce to user
				print_response(1, "nonce_return", ["nonce" => $nonce]);			
				die;
			
			break;
			
			#Adding score
			case "add_score":
				
				#Handle error for add score
				if (!isset($dict_from_json['score'])){
					print_response(0, "no_return", [], "missing_score");
					die;
				}
								
				if (!isset($dict_from_json['username'])){
					print_response(0, "no_return", [], "missing_username");
					die;
				}
				
				# Username max length 40, should be handled in Godot
				$username = $dict_from_json['username'];
				if (strlen($username) > 40)
					$username = substrt($username, 40);
				
				$score = $dict_from_json['score'];

				#Create sql to pass to DB
				$sql = "INSERT INTO `players_secure` (player_name, score) VALUES (:username, :score) ON DUPLICATE
				KEY UPDATE score = GREATEST(score, VALUES(score))";

				#Make a connection to the DB
				$pdo = OpenConnPDO();
				
				//Check for correct nonce (hashing), continue if OK
				if(!verify_nonce($pdo))
					die;
				
				$sth = $pdo -> prepare($sql);
				$sth -> bindValue("username", $username);
				$sth -> bindValue("score", $score, PDO::PARAM_INT);
				$sth -> execute(); 
				
				CloseConnPDO($pdo);
				
				#Response to Godot, all is fine				
				print_response(0, "no_return", array("size" => 0));
				die;

				
			break;
			
			case "get_scores":
			
				$score_number_of = 10;
				$score_offset = 0;
				
				#Check for new values
				if (isset($dict_from_json['score_offset']))
					$score_offset = max(0, (int)$dict_from_json['score_offset']);
								
				if (isset($dict_from_json['score_number']))
					$score_number_of = max(1, (int)$dict_from_json['score_number']);
				
			
				$sql = "SELECT id, player_name, score FROM players_secure ORDER BY score DESC LIMIT :limit OFFSET :offset";
				
				#Make a connection to the DB
				$pdo = OpenConnPDO();
				
				//Check for correct nonce (hashing), continue if OK
				if(!verify_nonce($pdo))
					die;
			
				// prepare and bind
				$sth = $pdo->prepare($sql);
				$sth -> bindValue("limit", $score_number_of, PDO::PARAM_INT);
				$sth -> bindValue("offset", $score_offset, PDO::PARAM_INT);
				
				#DB call 
				$sth->execute();
				
				$counter = 0;
				$players;
				while ($result = $sth->fetch(PDO::FETCH_ASSOC)) {
					$players[] = $result;
					#$player = $result->fetch_array(MYSQLI_ASSOC);
					$counter++;
				}					

				$players["dummy"] = "";
				$players = json_encode($players);
				
				#Close PDO object			
				CloseConnPDO($pdo);
				
				print_response($counter, "data_return", $players);
				die;
			
			
			break;
			
			case "get_player":
			
				#Handle missing user id
				if (!isset($dict_from_json['user_id'])){
					print_response(0, "no_return", [], "missing_user_id");
					die;
				}
				
				# Username max length 40, -> should be handled in Godot
				$user_id = $dict_from_json['user_id'];
				
			
				$sql = "SELECT * FROM players_secure WHERE id = :id;";
				
				#Make a connection to the DB
				$pdo = OpenConnPDO();
				
				//Check for correct nonce (hashing), continue if OK
				if(!verify_nonce($pdo))
					die;
			
				// prepare and bind
				$sth = $pdo->prepare($sql);
				$sth -> bindValue("id", $user_id, PDO::PARAM_INT);
				
				#DB call 
				$sth->execute();
				
				$counter = 0;
				$players;
				while ($result = $sth->fetch(PDO::FETCH_ASSOC)) {
					$players[] = $result;
					#$player = $result->fetch_array(MYSQLI_ASSOC);
					$counter++;
				}	
			
				$players["dummy"] = "";
				$players = json_encode($players);
				
				#Close result, statement and connection
				#$result->close();
				#$sth->close();				
				CloseConnPDO($pdo);
				
				print_response($counter, "data_return", $players);
				die;
			
			
			break;
				
			
			
			#Handle none excisting request
			default:
				print_reaponse([], "invalide_command");
				die;
			break;
		}

    ?>