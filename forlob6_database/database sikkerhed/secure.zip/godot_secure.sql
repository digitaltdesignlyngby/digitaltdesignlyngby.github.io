-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Vært: 127.0.0.1
-- Genereringstid: 26. 01 2025 kl. 17:25:27
-- Serverversion: 5.7.14
-- PHP-version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `godot_secure`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `nonces`
--

CREATE TABLE `nonces` (
  `ip_address` varchar(255) NOT NULL,
  `nonce` char(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `nonces`
--

INSERT INTO `nonces` (`ip_address`, `nonce`) VALUES
('127.0.0.1', '75317ae3c21185f0591125f563178eedf4654a4d0f76da1c80a0a01198ec2b42'),
('::1', '9aa8b5dcb6d06e01a6a0ade9d0656c45e75862be6b5466cd256f31e25c7e11fd');

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `players_secure`
--

CREATE TABLE `players_secure` (
  `id` int(11) NOT NULL,
  `player_name` varchar(40) CHARACTER SET utf8mb4 NOT NULL,
  `score` int(11) NOT NULL DEFAULT '0',
  `settings` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Data dump for tabellen `players_secure`
--

INSERT INTO `players_secure` (`id`, `player_name`, `score`, `settings`) VALUES
(1, 'Test player', 150, NULL),
(2, 'Bobby', 101, NULL),
(4, 'Doris', 110, NULL),
(6, 'Monkey', 300, NULL),
(8, 'Killer', 150, NULL);

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `nonces`
--
ALTER TABLE `nonces`
  ADD UNIQUE KEY `ip_address` (`ip_address`);

--
-- Indeks for tabel `players`
--
ALTER TABLE `players_secure`
  ADD PRIMARY KEY (`id`);

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `players`
--
ALTER TABLE `players_secure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
