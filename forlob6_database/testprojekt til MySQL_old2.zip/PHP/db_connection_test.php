    <?php
		function OpenCon()
		{
			$db_host = "localhost";
			$db_name = "godot_test";
			$db_username = "root";
			$db_password = "";
			
			$conn = new mysqli($db_host, $db_username, $db_password,$db_name);
			
			return $conn;
		}
		
		function CloseCon($conn)
		{
			$conn -> close();
		}
    ?>
	