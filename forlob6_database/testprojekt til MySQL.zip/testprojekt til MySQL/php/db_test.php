    <?php
		include 'db_connection_test.php';
		
		#Returns information and data to Godot
		function print_response($datasize, $dictionary = [], $error = "none"){
			
			
			$string = "{\"error\" : \"$error\",
						\"command\" : \"$_REQUEST[command]\",
						\"datasize\" : $datasize, 
						\"response\" :" . json_encode($dictionary) . "}";	

			#Print out json to Godot
			echo $string;
		}

		
		
		#Handle error: 
		#Missing command
		if (!isset($_REQUEST['command']) or $_REQUEST['command'] === null){
			//print_response([], "missing_command");
			echo "{\"error\":\"missing_command\",\"response\":{}}";
			die;
		}
		
		#Missing data
		if (!isset($_REQUEST['data']) or $_REQUEST['data'] === null){
			print_response(0,[], "missing_data");
			die;
		}
			
		
		#Convert Godot json to dictionary
		$dict_from_json = json_decode($_REQUEST['data'], true);

		
		#Is dictionary valid
		if ($dict_from_json === null){
			print_response([], "invalid_json");
			die;
		}
		
		switch ($_REQUEST['command']){
			
			#Adding score
			case "add_score":
				
				#Handle error for add score
				if (!isset($dict_from_json['score'])){
					print_response([], "missing_score");
					die;
				}
								
				if (!isset($dict_from_json['username'])){
					print_response([], "missing_username");
					die;
				}
				
				# Username max length 40, should be handled in Godot
				$username = $dict_from_json['username'];
				if (strlen($username) > 40)
					$username = substrt($username, 40);
				
				$score = $dict_from_json['score'];

				#Make a connection to the DB
				$conn = OpenCon();
				
				// Check connection
				if ($conn->connect_error) {
					print_response("0", [], "db_login_error");
					die();
				}
				
				#Create sql to pass to DB
				$sql = "INSERT INTO players (player_name, score) VALUES (?, ?) ON DUPLICATE
				KEY UPDATE score = GREATEST(score, VALUES(score));";
				
				// prepare and bind
				$stmt = $conn->prepare($sql);
				#s:string, i:integer, d:decimal(float), b:blob
				$stmt->bind_param("si", $username, $score);
				
				
				#DB call 
				$stmt->execute();
				
				#Close statement and connection
				$stmt->close();				
				CloseCon($conn);
				
				#Response to Godot, all is fine
				print_response("0", []);
				die;
				
			break;
			
			case "get_scores":
			
				$score_number_of = 10;
				$score_offset = 0;
				
				#Check for new values
				if (isset($dict_from_json['score_offset']))
					$score_offset = max(0, (int)$dict_from_json['score_offset']);
								
				if (isset($dict_from_json['score_number']))
					$score_number_of = max(1, (int)$dict_from_json['score_number']);
				
				#Make a connection to the DB
				$conn = OpenCon();
				
				// Check connection
				if ($conn->connect_error) {
					print_response([], "db_login_error");
					die();
				}
			
				$sql = "SELECT id, player_name, score FROM players ORDER BY score DESC LIMIT ? OFFSET ?";
				
				//echo($sql);
				//die;
			
				// prepare and bind
				$stmt = $conn->prepare($sql);
				#s:string, i:integer, d:decimal(float), b:blob
				$stmt->bind_param("ii", $score_number_of, $score_offset);
				
				#DB call 
				$stmt->execute();
				
				$result = $stmt->get_result();
				$players;
				$player = $result->fetch_array(MYSQLI_ASSOC);
				$counter = 0;
				while ($player != null)
				{
					$players[] = $player;
					$player = $result->fetch_array(MYSQLI_ASSOC);
					$counter++;
				} 

				$players["dummy"] = "";
				$players = json_encode($players);
				
				#Close result, statement and connection
				$result->close();
				$stmt->close();				
				CloseCon($conn);
				
				print_response($counter, $players);
				die;
			
			
			break;
			
			case "get_player":
			
				#Handle missing user id
				if (!isset($dict_from_json['user_id'])){
					print_response([], "missing_user_id");
					die;
				}
				
				# Username max length 40, -> should be handled in Godot
				$user_id = $dict_from_json['user_id'];
				
				#Make a connection to the DB
				$conn = OpenCon();
				
				// Check connection
				if ($conn->connect_error) {
					print_response([], "db_login_error");
					die();
				}				
			
				$sql = "SELECT * FROM players WHERE id = ?;";
			
				// prepare and bind
				$stmt = $conn->prepare($sql);
				#s:string, i:integer, d:decimal(float), b:blob
				$stmt->bind_param("i", $user_id);
				
				#DB call 
				$stmt->execute();
				
				$result = $stmt->get_result();
				$player = $result->fetch_array(MYSQLI_ASSOC);
				
				#Close result, statement and connection
				$result->close();
				$stmt->close();				
				CloseCon($conn);
				
				$datasize = sizeof($player);
				if ($datasize > 0) $datasize = 1;
				
				
				print_response($datasize, $player);
				die;
			
			
			break;
				
			
			
			#Handle none excisting request
			default:
				print_reaponse([], "invalide_command");
				die;
			break;
		}

    ?>