from Crypto.Util.number import inverse
from Crypto.Util import number
import binascii
flag=b"HKN{xxx_xxxx_and so on}"

f = open("transmission.txt","w")

prime_length = 512

p = number.getPrime(prime_length)
q= number.getPrime(prime_length)
n=p*q
e=65537
f.write("n = \n")
f.write('%d\n' % n)
f.write('e=%d\n' %e)
print("n=",n)
print(len(flag))
print(len(flag)//2)
for i in range(0,len(flag)//2):
    part_flag=flag[i*2:i*2+2]
    print(part_flag)
    hex_flag=binascii.hexlify(part_flag)
    int_flag=int(hex_flag,16)
    hack_int_encrypted=pow(int_flag,e,n)
    cipher=hex(hack_int_encrypted)
    f.write(cipher[2:])
    f.write("\n")

f.close()

g = open("private.txt","w")
g.write("n = \n")
g.write('%d\n' % n)
g.write('e=%d\n' %e)
g.write('p=%d\n' %p)
g.write('q=%d\n' %q)
phi=(p-1)*(q-1)

d=inverse(e,phi)
g.write('d=%d\n' %d)
g.close()



